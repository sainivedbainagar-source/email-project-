"""AbuseIPDB threat intelligence provider."""

import ipaddress
import os
from typing import Optional

import httpx

from app.models.threat_intel import (
    DomainThreatReport,
    IPClassification,
    IPThreatReport,
    IPType,
    ThreatStatus,
)
from app.services.threat_intel.base import BaseThreatIntelProvider


class AbuseIPDBProvider(BaseThreatIntelProvider):
    """Check public IP addresses with AbuseIPDB."""

    API_URL = "https://api.abuseipdb.com/api/v2/check"

    def __init__(self, api_key: Optional[str] = None, timeout: float = 5.0):
        self.api_key = api_key or os.getenv("ABUSEIPDB_API_KEY")
        self.timeout = timeout

    @property
    def name(self) -> str:
        return "abuseipdb"

    @staticmethod
    def _base_report(
        ip: str,
        status: ThreatStatus,
        score: Optional[int],
        details: str,
    ) -> IPThreatReport:
        try:
            obj = ipaddress.ip_address(ip)
            ip_type = IPType.IPV4 if obj.version == 4 else IPType.IPV6
            if obj.is_loopback:
                classification = IPClassification.LOOPBACK
            elif obj.is_link_local:
                classification = IPClassification.LINK_LOCAL
            elif obj.is_multicast:
                classification = IPClassification.MULTICAST
            elif obj.is_private:
                classification = IPClassification.PRIVATE
            elif obj.is_reserved or not obj.is_global:
                classification = IPClassification.RESERVED
            else:
                classification = IPClassification.PUBLIC
            routable = classification == IPClassification.PUBLIC
        except ValueError:
            ip_type = IPType.IPV4
            classification = IPClassification.RESERVED
            routable = False

        return IPThreatReport(
            ip=ip,
            ip_type=ip_type,
            classification=classification,
            is_routable=routable,
            threat_status=status,
            reputation_score=score,
            provider="abuseipdb",
            details=details,
        )

    @staticmethod
    def _status(score: int) -> ThreatStatus:
        if score <= 0:
            return ThreatStatus.BENIGN
        if score < 50:
            return ThreatStatus.SUSPICIOUS
        return ThreatStatus.MALICIOUS

    def lookup_ip(self, ip: str) -> IPThreatReport:
        """Look up one public IP. Failures are returned as safe report states."""
        clean_ip = ip.strip()

        try:
            obj = ipaddress.ip_address(clean_ip)
        except ValueError:
            return self._base_report(
                clean_ip,
                ThreatStatus.UNKNOWN,
                None,
                "Invalid or unparseable IP address format.",
            )

        if not obj.is_global:
            return self._base_report(
                clean_ip,
                ThreatStatus.NOT_CHECKED,
                None,
                "AbuseIPDB lookup skipped because the IP is not public.",
            )

        if not self.api_key:
            return self._base_report(
                clean_ip,
                ThreatStatus.NOT_CHECKED,
                None,
                "AbuseIPDB lookup skipped because ABUSEIPDB_API_KEY is not configured.",
            )

        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.get(
                    self.API_URL,
                    headers={"Accept": "application/json", "Key": self.api_key},
                    params={"ipAddress": clean_ip, "maxAgeInDays": 90},
                )
        except httpx.TimeoutException:
            return self._base_report(clean_ip, ThreatStatus.UNKNOWN, None, "AbuseIPDB request timed out.")
        except httpx.RequestError as exc:
            return self._base_report(
                clean_ip,
                ThreatStatus.UNKNOWN,
                None,
                f"AbuseIPDB request failed: {exc.__class__.__name__}.",
            )

        if response.status_code == 429:
            return self._base_report(clean_ip, ThreatStatus.UNKNOWN, None, "AbuseIPDB rate limit reached.")
        if response.status_code in (401, 403):
            return self._base_report(
                clean_ip,
                ThreatStatus.UNKNOWN,
                None,
                "AbuseIPDB authentication failed or API access was denied.",
            )
        if response.status_code >= 400:
            return self._base_report(
                clean_ip,
                ThreatStatus.UNKNOWN,
                None,
                f"AbuseIPDB API returned HTTP {response.status_code}.",
            )

        try:
            data = response.json().get("data", {})
            score = int(data["abuseConfidenceScore"])
        except (ValueError, TypeError, KeyError, AttributeError):
            return self._base_report(
                clean_ip,
                ThreatStatus.UNKNOWN,
                None,
                "AbuseIPDB returned an invalid response.",
            )

        score = max(0, min(100, score))
        total_reports = data.get("totalReports", 0)
        return self._base_report(
            clean_ip,
            self._status(score),
            score,
            f"AbuseIPDB abuse confidence score: {score}/100. Reported {total_reports} time(s).",
        )

    def lookup_domain(self, domain: str) -> DomainThreatReport:
        """AbuseIPDB does not provide domain reputation."""
        raise NotImplementedError("AbuseIPDB supports IP lookups only.")
