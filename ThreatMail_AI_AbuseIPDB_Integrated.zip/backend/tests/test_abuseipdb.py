"""Mocked tests for AbuseIPDB integration."""

import httpx

from app.models.threat_intel import IPClassification, ThreatStatus
from app.services.threat_intel.abuseipdb import AbuseIPDBProvider


def response(status=200, payload=None):
    return httpx.Response(
        status,
        json=payload or {},
        request=httpx.Request("GET", AbuseIPDBProvider.API_URL),
    )


def test_success(monkeypatch):
    provider = AbuseIPDBProvider(api_key="test-key")

    def fake_get(self, url, headers=None, params=None):
        assert headers["Key"] == "test-key"
        assert params["ipAddress"] == "8.8.8.8"
        return response(200, {"data": {"abuseConfidenceScore": 75, "totalReports": 12}})

    monkeypatch.setattr(httpx.Client, "get", fake_get)
    report = provider.lookup_ip("8.8.8.8")

    assert report.classification == IPClassification.PUBLIC
    assert report.threat_status == ThreatStatus.MALICIOUS
    assert report.reputation_score == 75
    assert report.provider == "abuseipdb"


def test_benign(monkeypatch):
    provider = AbuseIPDBProvider(api_key="test-key")
    monkeypatch.setattr(
        httpx.Client,
        "get",
        lambda *args, **kwargs: response(200, {"data": {"abuseConfidenceScore": 0}}),
    )
    report = provider.lookup_ip("1.1.1.1")
    assert report.threat_status == ThreatStatus.BENIGN
    assert report.reputation_score == 0


def test_suspicious(monkeypatch):
    provider = AbuseIPDBProvider(api_key="test-key")
    monkeypatch.setattr(
        httpx.Client,
        "get",
        lambda *args, **kwargs: response(200, {"data": {"abuseConfidenceScore": 25}}),
    )
    report = provider.lookup_ip("8.8.4.4")
    assert report.threat_status == ThreatStatus.SUSPICIOUS


def test_missing_key(monkeypatch):
    monkeypatch.delenv("ABUSEIPDB_API_KEY", raising=False)
    report = AbuseIPDBProvider().lookup_ip("8.8.8.8")
    assert report.threat_status == ThreatStatus.NOT_CHECKED
    assert report.reputation_score is None


def test_private_ip_not_checked(monkeypatch):
    provider = AbuseIPDBProvider(api_key="test-key")

    def fail(*args, **kwargs):
        raise AssertionError("Private IP must not reach AbuseIPDB")

    monkeypatch.setattr(httpx.Client, "get", fail)
    report = provider.lookup_ip("192.168.1.10")
    assert report.classification == IPClassification.PRIVATE
    assert report.threat_status == ThreatStatus.NOT_CHECKED


def test_rate_limit(monkeypatch):
    provider = AbuseIPDBProvider(api_key="test-key")
    monkeypatch.setattr(httpx.Client, "get", lambda *a, **k: response(429))
    report = provider.lookup_ip("8.8.8.8")
    assert report.threat_status == ThreatStatus.UNKNOWN
    assert "rate limit" in report.details.lower()


def test_api_error(monkeypatch):
    provider = AbuseIPDBProvider(api_key="test-key")
    monkeypatch.setattr(httpx.Client, "get", lambda *a, **k: response(500))
    report = provider.lookup_ip("8.8.8.8")
    assert report.threat_status == ThreatStatus.UNKNOWN
    assert "500" in report.details


def test_timeout(monkeypatch):
    provider = AbuseIPDBProvider(api_key="test-key")

    def fail(*args, **kwargs):
        raise httpx.TimeoutException("timeout")

    monkeypatch.setattr(httpx.Client, "get", fail)
    report = provider.lookup_ip("8.8.8.8")
    assert report.threat_status == ThreatStatus.UNKNOWN
    assert "timed out" in report.details.lower()


def test_network_error(monkeypatch):
    provider = AbuseIPDBProvider(api_key="test-key")

    def fail(*args, **kwargs):
        raise httpx.ConnectError("connection failed")

    monkeypatch.setattr(httpx.Client, "get", fail)
    report = provider.lookup_ip("8.8.8.8")
    assert report.threat_status == ThreatStatus.UNKNOWN


def test_invalid_response(monkeypatch):
    provider = AbuseIPDBProvider(api_key="test-key")
    monkeypatch.setattr(httpx.Client, "get", lambda *a, **k: response(200, {"data": {}}))
    report = provider.lookup_ip("8.8.8.8")
    assert report.threat_status == ThreatStatus.UNKNOWN
